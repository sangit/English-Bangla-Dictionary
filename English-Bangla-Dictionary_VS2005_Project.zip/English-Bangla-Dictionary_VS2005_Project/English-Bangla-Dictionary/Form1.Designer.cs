namespace English_Bangla_Dictionary
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBoxWord = new System.Windows.Forms.TextBox();
            this.dataGridViewWordList = new System.Windows.Forms.DataGridView();
            this.textBoxMeaning = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dictionaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishBanglaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.banglaEnglishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chmHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWordList)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxWord
            // 
            this.textBoxWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWord.Location = new System.Drawing.Point(12, 45);
            this.textBoxWord.Name = "textBoxWord";
            this.textBoxWord.Size = new System.Drawing.Size(655, 29);
            this.textBoxWord.TabIndex = 0;
            this.textBoxWord.TextChanged += new System.EventHandler(this.textBoxWord_TextChanged);
            this.textBoxWord.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxWord_KeyDown);
            this.textBoxWord.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxWord_KeyUp);
            this.textBoxWord.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBoxWord_MouseClick);
            // 
            // dataGridViewWordList
            // 
            this.dataGridViewWordList.AllowUserToResizeColumns = false;
            this.dataGridViewWordList.AllowUserToResizeRows = false;
            this.dataGridViewWordList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWordList.Location = new System.Drawing.Point(12, 80);
            this.dataGridViewWordList.MultiSelect = false;
            this.dataGridViewWordList.Name = "dataGridViewWordList";
            this.dataGridViewWordList.ReadOnly = true;
            this.dataGridViewWordList.RowHeadersVisible = false;
            this.dataGridViewWordList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewWordList.Size = new System.Drawing.Size(655, 259);
            this.dataGridViewWordList.TabIndex = 3;
            this.dataGridViewWordList.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dataGridViewWordList_Scroll);
            this.dataGridViewWordList.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewWordList_CellMouseClick);
            // 
            // textBoxMeaning
            // 
            this.textBoxMeaning.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMeaning.Location = new System.Drawing.Point(12, 358);
            this.textBoxMeaning.Multiline = true;
            this.textBoxMeaning.Name = "textBoxMeaning";
            this.textBoxMeaning.ReadOnly = true;
            this.textBoxMeaning.Size = new System.Drawing.Size(655, 124);
            this.textBoxMeaning.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Word:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Purple;
            this.label2.Location = new System.Drawing.Point(12, 342);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Meaning:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dictionaryToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(679, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dictionaryToolStripMenuItem
            // 
            this.dictionaryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishBanglaToolStripMenuItem,
            this.banglaEnglishToolStripMenuItem});
            this.dictionaryToolStripMenuItem.Name = "dictionaryToolStripMenuItem";
            this.dictionaryToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.dictionaryToolStripMenuItem.Text = "&Dictionary";
            // 
            // englishBanglaToolStripMenuItem
            // 
            this.englishBanglaToolStripMenuItem.Checked = true;
            this.englishBanglaToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.englishBanglaToolStripMenuItem.Name = "englishBanglaToolStripMenuItem";
            this.englishBanglaToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.englishBanglaToolStripMenuItem.Text = "&English-Bangla";
            this.englishBanglaToolStripMenuItem.Click += new System.EventHandler(this.englishBanglaToolStripMenuItem_Click);
            // 
            // banglaEnglishToolStripMenuItem
            // 
            this.banglaEnglishToolStripMenuItem.Name = "banglaEnglishToolStripMenuItem";
            this.banglaEnglishToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.banglaEnglishToolStripMenuItem.Text = "&Bangla-English";
            this.banglaEnglishToolStripMenuItem.Click += new System.EventHandler(this.banglaEnglishToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chmHelpToolStripMenuItem,
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "&Help";
            // 
            // chmHelpToolStripMenuItem
            // 
            this.chmHelpToolStripMenuItem.Name = "chmHelpToolStripMenuItem";
            this.chmHelpToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.chmHelpToolStripMenuItem.Text = "&Chm Help";
            this.chmHelpToolStripMenuItem.Click += new System.EventHandler(this.chmHelpToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.aboutToolStripMenuItem1.Text = "&License";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 494);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxMeaning);
            this.Controls.Add(this.dataGridViewWordList);
            this.Controls.Add(this.textBoxWord);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "English-Bangla-Dictionary";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWordList)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxWord;
        private System.Windows.Forms.DataGridView dataGridViewWordList;
        private System.Windows.Forms.TextBox textBoxMeaning;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dictionaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem banglaEnglishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishBanglaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chmHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
    }
}

