using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;

namespace English_Bangla_Dictionary
{
    public partial class Form1 : Form
    {
        StringCollection myColEnglish = new StringCollection();
        StringCollection myColBangla = new StringCollection();
                             
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            dataGridViewWordList.ColumnCount = 2;
            dataGridViewWordList.Columns[0].Name = "English";
            dataGridViewWordList.Columns[0].Width =150;
            dataGridViewWordList.Columns[1].Name = "Bangla";
            dataGridViewWordList.Columns[1].Width = 485;

            ParseDictionary("BnToEnDictionary.txt");           
        }

        private void dataGridViewWordList_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = dataGridViewWordList.CurrentCell.RowIndex;
            if (dataGridViewWordList.Rows[rowIndex].Cells[1].Value != null) textBoxMeaning.Text = dataGridViewWordList.Rows[rowIndex].Cells[1].Value.ToString();
            if (dataGridViewWordList.Rows[rowIndex].Cells[0].Value != null) textBoxWord.Text = dataGridViewWordList.Rows[rowIndex].Cells[0].Value.ToString();
        }

        private void textBoxWord_TextChanged(object sender, EventArgs e)
        {
            String word = textBoxWord.Text;
            if (word == "")
            {
                dataGridViewWordList.Rows.Clear();

                if (englishBanglaToolStripMenuItem.Checked) 
                {
                    for (int i = 0; i < myColEnglish.Count; i++)
                    {
                        string[] row = { myColEnglish[i], myColBangla[i] };
                        dataGridViewWordList.Rows.Add(row);
                    }
                }
                else 
                {
                    for (int i = 0; i < myColBangla.Count; i++)
                    {
                        string[] row = { myColBangla[i], myColEnglish[i] };
                        dataGridViewWordList.Rows.Add(row);
                    }
                }
            }
            else FindWord(word);
        }

        private void ParseDictionary(String DictionaryFile)
        {
            try
            {
                // Create an instance of StreamReader to read from a file.
                // The using statement also closes the StreamReader.
                using (StreamReader sr = new StreamReader(DictionaryFile))
                {
                    String line;
                    // Read and display lines from the file until the end of 
                    // the file is reached.

                    while ((line = sr.ReadLine()) != null)
                    {
                        int n = line.IndexOf('=');
                        myColEnglish.Add(line.Substring(0, n));
                        myColBangla.Add(line.Substring(n + 1, line.Length - (n + 1)));

                        // initially englishBanglaToolStripMenuItem.Checked == true
                        string[] row = { line.Substring(0, n), line.Substring(n + 1, line.Length - (n + 1)) };
                        dataGridViewWordList.Rows.Add(row);
                     }
                }
            }
            catch
            {
                // Let the user know what went wrong.
                MessageBox.Show("Error in reading the dictionary");
            }
        }

        private void dataGridViewWordList_Scroll(object sender, ScrollEventArgs e)
        {
            if (textBoxWord.Text == "")
            {
                int valVScroll = e.NewValue;
            }
        }

        private void FindWord(String word)
        {
            dataGridViewWordList.Rows.Clear();

            if (englishBanglaToolStripMenuItem.Checked)
            {
                for (int i = 0; i < myColEnglish.Count; i++)
                {
                    String buffer;
                    if (myColEnglish[i].Length >= word.Length) buffer = myColEnglish[i].Substring(0, word.Length);
                    else buffer = myColEnglish[i];

                    if (buffer == word.ToLower())
                    {
                        string[] row = { myColEnglish[i], myColBangla[i] };
                        dataGridViewWordList.Rows.Add(row);
                    }
                }
            }
            else
            {
                for (int i = 0; i < myColBangla.Count; i++)
                {
                    String buffer;
                    if (myColBangla[i].Length >= word.Length) buffer = myColBangla[i].Substring(0, word.Length);
                    else buffer = myColBangla[i];

                    if (buffer == word)
                    {
                        string[] row = { myColBangla[i], myColEnglish[i] };
                        dataGridViewWordList.Rows.Add(row);
                    }
                }
            }          
        }

        private void textBoxWord_KeyUp(object sender, KeyEventArgs e)
        {
            textBoxMeaning.Text = "";

        }

        private void textBoxWord_KeyDown(object sender, KeyEventArgs e)
        {
            // the paste event
            if (e.KeyCode == Keys.ControlKey && e.KeyCode == Keys.V) textBoxMeaning.Text = "";
        }

        private void textBoxWord_MouseClick(object sender, MouseEventArgs e)
        {
           if (e.Button == MouseButtons.Left)  textBoxMeaning.Text = "";
        }

        private void banglaEnglishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!banglaEnglishToolStripMenuItem.Checked)
            {
                englishBanglaToolStripMenuItem.Checked = false;
                banglaEnglishToolStripMenuItem.Checked = true;
                dataGridViewWordList.Columns[1].Name = "English";
                dataGridViewWordList.Columns[1].Width = 150;
                dataGridViewWordList.Columns[0].Name = "Bangla";
                dataGridViewWordList.Columns[0].Width = 485;
                SwitchGridData();
                textBoxMeaning.Text = "";
                textBoxWord.Text = "";
            }
        }

        private void englishBanglaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!englishBanglaToolStripMenuItem.Checked)
            {
                englishBanglaToolStripMenuItem.Checked = true;
                banglaEnglishToolStripMenuItem.Checked = false;
                dataGridViewWordList.Columns[0].Name = "English";
                dataGridViewWordList.Columns[0].Width = 150;
                dataGridViewWordList.Columns[1].Name = "Bangla";
                dataGridViewWordList.Columns[1].Width = 485;
                SwitchGridData();
                textBoxMeaning.Text = "";
                textBoxWord.Text = "";
            }
        }

        private void SwitchGridData()
        {
            for (int rowIndex = 0; rowIndex < dataGridViewWordList.Rows.Count; rowIndex++)
            {
                if ((dataGridViewWordList.Rows[rowIndex].Cells[1].Value != null) && (dataGridViewWordList.Rows[rowIndex].Cells[0].Value != null))
                {
                    Object obj = dataGridViewWordList.Rows[rowIndex].Cells[0].Value;
                    dataGridViewWordList.Rows[rowIndex].Cells[0].Value = dataGridViewWordList.Rows[rowIndex].Cells[1].Value;
                    dataGridViewWordList.Rows[rowIndex].Cells[1].Value = obj;
                }
            }
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 AboutForm = new Form2();
            AboutForm.ShowDialog();
        }

        private void chmHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "help.chm");
        }
    }
}